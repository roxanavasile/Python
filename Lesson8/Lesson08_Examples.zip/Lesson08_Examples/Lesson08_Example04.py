def main():
    texas()
    california()
# end of def main

def texas():
    birds = 5000
    print('texas has', birds, 'birds.')
# end of def texas

def california():
    birds = 8000
    print('calofirnia has', birds, 'birds.')
# end of def calfornia

main()
