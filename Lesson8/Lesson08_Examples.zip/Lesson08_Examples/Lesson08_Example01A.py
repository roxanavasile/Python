def chooseEntree():
    print('Entree:')
    print('Enter 1 for fish and chips')
    print('Enter 2 for burger and fries')
    print('Enter 3 for fried chicken and smashed potato')
    print('Enter 4 for barbecue pork')
    entree = int(input('Please enter your choice: '))
    if entree == 1:
        print('You have chosen fish and chips')
    elif entree == 2:
        print('You have chosen burger and fries')
    elif entree == 3:
        print('You have chosen fried chicken and smashed potato')
    elif entree == 4:
        print('You have chosen barbecue pork')
# end of def chooseEntree

def chooseBeverage():
    print('Beverage:')
    print('Enter 1 for iced tea')
    print('Enter 2 for soda')
    print('Enter 3 for coffee')
    beverage = int(input('Please enter your choice: '))
    if beverage == 1:
        print('You have chosen iced tea')
    elif beverage == 2:
        print('You have chosen soda')
    elif beverage == 3:
        print('You have chosen coffee')
# end of def chooseBeverage

chooseEntree()         # use chooseEntree
chooseBeverage()    # use choseBeverage
