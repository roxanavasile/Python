def main():
    intro()
    cups_needed = int(input('Enter the number of cups: '))
    cups_to_ounces(cups_needed)   # pass cups_needed
# end of def main

def intro():
    print('This program converts measurements')
    print('in cups to fluid ounces. For your')
    print('reference the formula is:')
    print('1 cup = 8 fluid ounces')
    print()
# end of def intro

def cups_to_ounces(cups):   # cups receives data
    ounces = cups * 8
    print('That converts to', ounces, 'ounces.')
# end of def cups_to_ounces

main()
