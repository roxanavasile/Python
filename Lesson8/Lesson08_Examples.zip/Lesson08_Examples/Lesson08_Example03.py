def main():
    get_name()
    print('Hello', name)    # variable name inaccessible
# end of def main

def get_name():
    name = input('Enter your name: ')
# end of def get_name

main()
