def main():
    print('Welcome to the voice mail system of the college transfer division.')
    print('Please enter 1 for English department')
    print('Please enter 2 for Math department')
    print('Please enter 3 for Physics department')
    print('Please enter anything else to reach the secretary.')
    deptChoice = input('Enter department choice: ')
    if deptChoice == '1':
        engDept()
    elif deptChoice == '2':
        mathDept()
    elif deptChoice == '3':
        phyDept()
    else:
        secretary()
# end of def main

def engDept():
    print('You have reached the English department.')
    print('Please enter 1 for Richard Cox')
    print('Please enter 2 for James Miffin')
    print('Please enter anything else to reach the secretary.')
    instChoice = input('Enter instructor choice: ')
    if instChoice == '1':
        print('You have reached the voice mail of Richard Cox.')
    elif instChoice == '2':
        print('You have reached the voice mail of James Miffin.')
    else:
        secretary()
# end of def engDept

def mathDept():
    print('You have reached the Math department.')
    print('Please enter 1 for Susan Moore')
    print('Please enter 2 for Christine Richon')
    print('Please enter anything else to reach the secretary.')
    instChoice = input('Enter instructor choice: ')
    if instChoice == '1':
        print('You have reached the voice mail of Susan Moore.')
    elif instChoice == '2':
        print('You have reached the voice mail of Christine Richon.')
    else:
        secretary()
# end of def mathDept

def phyDept():
    print('You have reached the Physics department.')
    print('Please enter 1 for Jeremy Davis')
    print('Please enter anything else to reach the secretary.')
    instChoice = input('Enter instructor choice: ')
    if instChoice == '1':
        print('You have reached the voice mail of Susan Moore.')
    else:
        secretary()
# end of def phyDept

def secretary():
    print('You have reached the secretary of the division.')
# end of def secretary

main()   # call main function
