def main():
    name_list = []  # create an empty list
    again = 'y'

    while again == 'y':
        name = input('Enter a name: ')
        name_list.append(name)
        again = input('Do you want to add another name? [y/n]')
        again  = again.lower()
        print()

    print('Here are the names you entered.')
    for name in name_list:
        print(name)
# end of def main

main()
