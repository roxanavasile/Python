def main():
    names = ['James', 'Kathryn', 'Bill']
    print('The list before the insert:')
    print(names)
    names.insert(0, 'Joe')
    print('The list after the insert:')
    print(names)
# end of def main
    
main()
