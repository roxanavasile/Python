def main():
    my_list = [1,2,3,4,5]
    print('Before deletion:', my_list)
    del my_list[2]
    print('After deletion:', my_list)
# end of def main

main()
