def main():
    my_list = [1,2,3,4,5]
    print('Original order:', my_list)
    my_list.reverse()
    print('Reversed:', my_list)
# end of def main

main()
