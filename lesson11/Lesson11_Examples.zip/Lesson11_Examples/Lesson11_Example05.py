def main():
    my_list = [9,1,0,2,8,6,7,4,5,3]
    print('Original order:', my_list)
    my_list.sort()
    print('Sorted order:', my_list)
# end of def main

main()
