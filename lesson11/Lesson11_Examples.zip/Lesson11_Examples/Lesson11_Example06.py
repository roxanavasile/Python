def main():
    food = ['Pzza', 'Burgers', 'Chips']
    print('Here are the items in the food list:')
    print(food)
    item = input('Which item should I remove? ')
    if item not in food:
        print('That item was not found in the list')
    else:
        food.remove(item)
        print('Here is the revised list:')
        print(food)
# end of def main

main()
