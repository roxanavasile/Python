def main():
    my_list = [5, 4, 3, 2, 50, 40, 30]
    smallest = min(my_list)
    largest = max(my_list)
    print('The lowest value is', smallest)
    print('The highest value is', largest)
# end of def main

main()
